import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class MapScreenContent extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const MapScreenContent({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text('Карта'));
  }
}
