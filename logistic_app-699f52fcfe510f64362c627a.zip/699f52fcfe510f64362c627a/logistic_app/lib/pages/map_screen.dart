import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:logistic_app/globals/app_state.dart';
import 'package:logistic_app/pages/shipment_details_screen.dart';

@NowaGenerated()
class MapScreen extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppState.of(context);
    return ShipmentDetailsScreen(shipment: state.currentShipment);
  }
}
