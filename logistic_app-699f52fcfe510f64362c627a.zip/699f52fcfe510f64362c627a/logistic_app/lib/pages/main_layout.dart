import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:logistic_app/globals/app_state.dart';
import 'package:logistic_app/components/home_screen.dart';
import 'package:logistic_app/pages/map_screen_content.dart';

@NowaGenerated()
class MainLayout extends StatefulWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() {
    return _MainLayoutState();
  }
}

@NowaGenerated()
class _MainLayoutState extends State<MainLayout> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final state = AppState.of(context);
    Widget currentScreen;
    if (_currentIndex == 0) {
      currentScreen = const HomeScreen();
    } else if (_currentIndex == 2) {
      currentScreen = const MapScreenContent();
    } else {
      currentScreen = const Center(
        child: Text(
          'Раздел в разработке',
          style: TextStyle(color: Colors.grey),
        ),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FB),
      body: currentScreen,
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 20,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildNavItem(0, Icons.home_outlined, Icons.home, 'Главная'),
            _buildNavItem(
              1,
              Icons.inventory_2_outlined,
              Icons.inventory_2,
              'Посылки',
            ),
            _buildAddButton(),
            _buildNavItem(
              2,
              Icons.location_on_outlined,
              Icons.location_on,
              'Карта',
            ),
            _buildNavItem(3, Icons.person_outline, Icons.person, 'Профиль'),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(
    int index,
    IconData outlineIcon,
    IconData filledIcon,
    String label,
  ) {
    final isSelected = _currentIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _currentIndex = index),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isSelected ? filledIcon : outlineIcon,
            color: isSelected
                ? const Color(0xFF1A1A1A)
                : Colors.grey.withValues(alpha: 0.6),
            size: 26,
          ),
          if (isSelected)
            Container(
              margin: const EdgeInsets.only(top: 4),
              width: 4,
              height: 4,
              decoration: const BoxDecoration(
                color: Color(0xFF1A1A1A),
                shape: BoxShape.circle,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildAddButton() {
    return Container(
      width: 48,
      height: 48,
      decoration: const BoxDecoration(
        color: Color(0xFF1A1A1A),
        shape: BoxShape.circle,
      ),
      child: const Icon(Icons.add, color: Colors.white, size: 24),
    );
  }
}
