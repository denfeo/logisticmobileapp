import 'package:go_router/go_router.dart';
import 'package:logistic_app/pages/main_layout.dart';
import 'package:logistic_app/pages/home_page.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
final GoRouter appRouter = GoRouter(
  initialLocation: '/main-layout',
  routes: [
    GoRoute(
      path: '/main-layout',
      builder: (context, state) => const MainLayout(),
    ),
    GoRoute(path: '/home-page', builder: (context, state) => const HomePage()),
  ],
);
