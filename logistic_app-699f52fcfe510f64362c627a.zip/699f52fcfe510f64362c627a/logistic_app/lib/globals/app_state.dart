import 'package:flutter/material.dart';
import 'package:logistic_app/globals/themes.dart';
import 'package:nowa_runtime/nowa_runtime.dart';
import 'package:logistic_app/shipment.dart';
import 'package:logistic_app/shipment_status.dart';
import 'package:provider/provider.dart';

@NowaGenerated()
class AppState extends ChangeNotifier {
  AppState();

  factory AppState.of(BuildContext context, {bool listen = true}) {
    return Provider.of<AppState>(context, listen: listen);
  }

  ThemeData _theme = lightTheme;

  ThemeData get theme {
    return _theme;
  }

  int _currentTabIndex = 0;

  int get currentTabIndex {
    return _currentTabIndex;
  }

  final List<Shipment> _shipments = [
    Shipment(
      id: 'H314315796',
      name: 'Mac Mini M4 Pro',
      from: 'Дирия, Эр-Рияд',
      to: 'Джавра, Джидда',
      dateCreated: DateTime(2025, 10, 18),
      estimatedDelivery: DateTime(2025, 10, 19),
      status: ShipmentStatus.transit,
      cost: 120,
      quantity: 1,
      weight: 10,
      customerName: 'Ахмад Кавсар',
      courierName: 'Халид Омор',
      courierPhoto:
          'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200',
      progress: 0.6,
    ),
    Shipment(
      id: 'K37856307',
      name: 'Sonos Speaker',
      from: 'Эр-Рияд',
      to: 'Медина',
      dateCreated: DateTime(2025, 10, 15),
      estimatedDelivery: DateTime(2025, 10, 17),
      status: ShipmentStatus.delivered,
      cost: 85.5,
      quantity: 2,
      weight: 5.2,
      customerName: 'Сара Али',
      courierName: 'Омар Фарук',
      courierPhoto:
          'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200',
      progress: 1,
    ),
  ];

  List<Shipment> get shipments {
    return _shipments;
  }

  Shipment get currentShipment {
    return _shipments.first;
  }

  void changeTheme(ThemeData theme) {
    _theme = theme;
    notifyListeners();
  }

  void setTabIndex(int index) {
    _currentTabIndex = index;
    notifyListeners();
  }
}
