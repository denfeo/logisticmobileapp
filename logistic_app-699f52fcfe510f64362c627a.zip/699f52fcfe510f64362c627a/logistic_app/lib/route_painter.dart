import 'package:flutter/material.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class RoutePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;
    final path = Path();
    path.moveTo(size.width * 0.2, size.height * 0.8);
    path.quadraticBezierTo(
      size.width * 0.4,
      size.height * 0.2,
      size.width * 0.8,
      size.height * 0.3,
    );
    canvas.drawPath(path, paint);
    final dotPaint = Paint()..style = PaintingStyle.fill;
    dotPaint.color = Colors.black;
    canvas.drawCircle(Offset(size.width * 0.2, size.height * 0.8), 8, dotPaint);
    dotPaint.color = const Color(0xFFFF7A45);
    canvas.drawCircle(
      Offset(size.width * 0.8, size.height * 0.3),
      10,
      dotPaint,
    );
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}
