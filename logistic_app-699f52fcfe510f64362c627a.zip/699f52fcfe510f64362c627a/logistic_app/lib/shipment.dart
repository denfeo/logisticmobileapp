import 'package:logistic_app/shipment_status.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class Shipment {
  Shipment({
    required this.id,
    required this.name,
    required this.from,
    required this.to,
    required this.dateCreated,
    required this.estimatedDelivery,
    required this.status,
    required this.cost,
    required this.quantity,
    required this.weight,
    required this.customerName,
    required this.courierName,
    required this.courierPhoto,
    this.progress = 0.5,
  });

  final String id;

  final String name;

  final String from;

  final String to;

  final DateTime dateCreated;

  final DateTime estimatedDelivery;

  final ShipmentStatus status;

  final double cost;

  final int quantity;

  final double weight;

  final String customerName;

  final String courierName;

  final String courierPhoto;

  final double progress;
}
