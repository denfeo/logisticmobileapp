import 'package:flutter/material.dart';
import 'package:logistic_app/shipment_status.dart';
import 'package:nowa_runtime/nowa_runtime.dart';

@NowaGenerated()
class ShipmentBadge extends StatelessWidget {
  @NowaGenerated({'loader': 'auto-constructor'})
  const ShipmentBadge({super.key, required this.status});

  final ShipmentStatus status;

  @override
  Widget build(BuildContext context) {
    Color color = Colors.grey;
    String text = 'Неизвестно';
    if (status == ShipmentStatus.transit) {
      color = const Color(0xFF2196F3);
      text = 'В пути';
    } else if (status == ShipmentStatus.onProcess) {
      color = const Color(0xFFFF9800);
      text = 'В обработке';
    } else if (status == ShipmentStatus.delivered) {
      color = const Color(0xFF4CAF50);
      text = 'Доставлено';
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
